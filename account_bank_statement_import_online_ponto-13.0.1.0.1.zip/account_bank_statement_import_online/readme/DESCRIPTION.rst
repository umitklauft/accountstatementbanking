This module provides base for building online bank statements providers.
