To pull historical bank statements:

#. Go to *Invoicing > Configuration > Bank Accounts*
#. Select specific bank accounts
#. Launch *Actions > Online Bank Statements Pull Wizard*
#. Configure date interval and click *Pull*

**NOTE**: To access these features, user needs to belong to
*Show Full Accounting Features* group.
