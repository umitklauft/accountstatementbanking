To pull historical bank statements:

#. Go to *Invoicing > Configuration > Bank Accounts*
#. Select specific bank accounts
#. Launch *Actions > Online Bank Statements Pull Wizard*
#. Configure date interval and click *Pull*

If historical data is not needed, then just simply wait for the scheduled
activity "Pull Online Bank Statements" to be executed for getting new
transactions.
